#!/usr/bin/python
# -*- coding: UTF-8 -*-
""" 
@author: Muxia
@time: 2020-10-25 
"""
# from .main import get_app
import sys
# from .main import get_app

from fastapi_demo.main import get_app


app = get_app()



