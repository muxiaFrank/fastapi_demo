# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['fastapi_demo',
 'fastapi_demo.api',
 'fastapi_demo.api.v1',
 'fastapi_demo.core',
 'fastapi_demo.core.config',
 'fastapi_demo.items',
 'fastapi_demo.models',
 'fastapi_demo.router',
 'fastapi_demo.tasks']

package_data = \
{'': ['*']}

install_requires = \
['celery>=5.0.1,<6.0.0',
 'fastapi>=0.61.1,<0.62.0',
 'flower>=0.9.5,<0.10.0',
 'uvicorn>=0.12.2,<0.13.0']

setup_kwargs = {
    'name': 'fastapi-demo',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
